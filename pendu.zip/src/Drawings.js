import React from 'react'

import './Drawings.css'

const Drawings = () => (
    <div className='drawings'>
        <canvas className='canvas' id="myCanvas"></canvas>
    </div>
)


export default Drawings